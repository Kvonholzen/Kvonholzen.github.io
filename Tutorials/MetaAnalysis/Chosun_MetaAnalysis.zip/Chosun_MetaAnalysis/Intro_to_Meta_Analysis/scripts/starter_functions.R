
r2 <- function(x){ round(x, 3)}

psig <- function(x){
  ifelse(x < .001, "< .001",
         #ifelse(x < .001, "< .001",
         #ifelse(x < .01, "< .01",
         ifelse(x > .001 & x < .05, paste("=", r2(x), sep = " "), paste("=", r2(x), sep = " ")))#))
}



g_SE <- function(x) paste0(r2(x$estimate), " (SE = ", r2(x$se), ")")

CI_95 <- function(x) paste0("[", r2(x$ci.lb), ", ", r2(x$ci.ub), "]")

CI_p <- function(x) paste0("(CI [", r2(x$ci.lb), ", ", r2(x$ci.ub), "], *p* ", psig(x$pval), ")")

full_estimate <- function(x) paste0(" = ", r2(x$estimate), ", SE = ", r2(x$se), ", 95% CI[",  r2(x$ci.lb), ", ", r2(x$ci.ub),"], *p* ", psig(x$pval))

# moderator test
mod_test <- function(x) paste0("QM(", r2(x$m), ") = ", r2(x$QM), ", *p* ", psig(x$QMp))