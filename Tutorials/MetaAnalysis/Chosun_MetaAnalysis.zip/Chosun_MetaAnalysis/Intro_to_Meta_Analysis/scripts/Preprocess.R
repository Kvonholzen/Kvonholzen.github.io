#### Preprocess Effect Size Database ####

# This script was written to preprocess the effect size database of a meta-analysis
# original written by Dr. Christina Bergmann
# modification of original by Dr. Katie Von Holzen
# katie.m.vonholzen@gmail.com
# last modified: July 28, 2020
########################################

noES <- db_ET %>%
  filter(is.na(d_calc)) %>%
  group_by(short_cite) %>%
  summarise(n_records = n())

# typing/running 
# View(noES)
# will give you a list of the papers that don't have enough data to compute an effect size

# line of code to get a unique identifier for study_ID, expt_num, and same_participant
db_ET$same_participant_calc <- paste(db_ET$study_ID, db_ET$expt_num, db_ET$same_participant, sep = "_")


# remove rows that don't have enough information to calculate an effect size
db_ET <- db_ET %>%
  filter(!is.na(d_calc))


# if there is a Hedges' g score that is an outlier, we want to remove it

Hedg_g_mean <- mean(db_ET$g_calc, na.rm = T)
Hedg_g_SD <- sd(db_ET$g_calc, na.rm = T)


#remove rows where Hedges' g is more than 3 standard deviations greater or lower than the mean
db_ET$nooutlier = ifelse(db_ET$g_calc > Hedg_g_mean + 3*Hedg_g_SD 
                            | db_ET$g_calc < Hedg_g_mean - 3*Hedg_g_SD,FALSE, TRUE)

n_outlier = sum(db_ET$nooutlier==FALSE)

n_outlier <- db_ET %>%
  filter(nooutlier == FALSE) %>%
  group_by(same_participant_calc) %>%
  summarise(n_records = n())


# remove the outliers
db_ET = db_ET[db_ET$nooutlier,]


# some extras to help sorting out unique information later

db_ET$short_cite.same_participant_calc <- paste0(db_ET$short_cite, ".", db_ET$same_participant_calc)
db_ET$unique_row <- factor(seq(from = 1, to = nrow(db_ET), by = 1))


dat <- db_ET



